import 'package:flutter/material.dart';
import 'calculator.dart';

main() {
  runApp(
    MaterialApp(
      debugShowCheckedModeBanner: false,
      initialRoute: '/calculator',
      routes: {
        '/calculator': (context) => calculator(),
      },
    ),
  );
}
