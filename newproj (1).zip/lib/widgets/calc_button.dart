import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class calc_button extends StatelessWidget {
  final String Number; //inside string
  final int bg; //background color
  final int tc; //text color
  final Function callback;

  const calc_button({
    this.Number,
    this.bg,
    this.tc,
    this.callback,
  });
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(10),
      child: SizedBox(
        height: 75,
        width: 80,
        child: FlatButton(
          shape: BeveledRectangleBorder(
            borderRadius: BorderRadius.circular(10.0),
          ), //shape
          child: Text(
            Number,
            style: GoogleFonts.rubik(
              textStyle: TextStyle(
                fontSize: 24,
              ), //ts
            ), //rubik
          ), //text
          onPressed: () => {}, //onpressed
          color: Color(bg),
          textColor: Color(tc),
        ),
        //button
      ), //sized box
    ); //container
  }
}
