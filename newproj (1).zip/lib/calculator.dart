import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import './widgets/calc_button.dart';

class calculator extends StatefulWidget {
  @override
  _calculatorState createState() => _calculatorState();
}

class _calculatorState extends State<calculator> {
  //vars
  int num1;
  int num2;
  String history = '';
  String oper;
  String res;
  String disp = '';

  void btnOnClick(String btnVal) {
    print(btnVal);
    if (btnVal == '+' || btnVal == '-' || btnVal == '*' || btnVal == '/') {
    } else {
      res = int.parse(disp + btnVal).toString();
    }

    setState(() {
      disp = res;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF28527a),
      //
      appBar: AppBar(
        backgroundColor: Colors.blueGrey,
        title: Text(
          'AliHasnain Calculator',
          style: GoogleFonts.lato(
            textStyle: TextStyle(
              letterSpacing: 2,
            ), //ts
          ), //rubik
        ),
        centerTitle: true,
      ),
      body: Container(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            //typed
            Container(
              child: Padding(
                padding: EdgeInsets.only(right: 12),
                child: Text(
                  '12345',
                  style: GoogleFonts.lato(
                    textStyle: TextStyle(
                      letterSpacing: 2,
                      fontSize: 24,
                      color: Color(0x66FFFFFF),
                    ), //ts
                  ), //lato
                ), //text
              ), //padding
              alignment: Alignment(1.0, 1.0),
            ), //cont
            //typed

            //answer
            Container(
              child: Padding(
                padding: EdgeInsets.all(12),
                child: Text(
                  '12345',
                  style: GoogleFonts.lato(
                    textStyle: TextStyle(
                      letterSpacing: 2,
                      fontSize: 48,
                      color: Colors.white,
                    ), //ts
                  ), //lato
                ), //text
              ), //padding
              alignment: Alignment(1.0, 1.0),
            ), //cont

            //answer
            Row(
              children: [
                //pehla button
                calc_button(
                  Number: '9',
                  bg: 0xFF8ac4d0,
                  tc: 0xFFFFFFFF,
                  callback: btnOnClick,
                ),
                calc_button(
                  Number: '8',
                  bg: 0xFF8ac4d0,
                  tc: 0xFFFFFFFF,
                  callback: btnOnClick,
                ),
                calc_button(
                  Number: '7',
                  bg: 0xFF8ac4d0,
                  tc: 0xFFFFFFFF,
                  callback: btnOnClick,
                ),
                calc_button(
                  Number: '6',
                  bg: 0xFF8ac4d0,
                  tc: 0xFFFFFFFF,
                  callback: btnOnClick,
                ),
              ], //row k backay
            ), //row

            Row(
              children: [
                //pehla button
                calc_button(
                  Number: '5',
                  bg: 0xFF8ac4d0,
                  tc: 0xFFFFFFFF,
                  callback: btnOnClick,
                ),
                calc_button(
                  Number: '4',
                  bg: 0xFF8ac4d0,
                  tc: 0xFFFFFFFF,
                  callback: btnOnClick,
                ),
                calc_button(
                  Number: '3',
                  bg: 0xFF8ac4d0,
                  tc: 0xFFFFFFFF,
                  callback: btnOnClick,
                ),
                calc_button(
                  Number: '2',
                  bg: 0xFF8ac4d0,
                  tc: 0xFFFFFFFF,
                  callback: btnOnClick,
                ),
              ], //row k backay
            ), //row

            Row(
              children: [
                //pehla button
                calc_button(
                  Number: '1',
                  bg: 0xFF8ac4d0,
                  tc: 0xFFFFFFFF,
                  callback: btnOnClick,
                ),
                calc_button(
                  Number: '0',
                  bg: 0xFF8ac4d0,
                  tc: 0xFFFFFFFF,
                  callback: btnOnClick,
                ),
                calc_button(
                  Number: '.',
                  bg: 0xFFf4d160,
                  tc: 0xFF000000,
                  callback: btnOnClick,
                ),
                calc_button(
                  Number: '=',
                  bg: 0xFFf4d160,
                  tc: 0xFF000000,
                  callback: btnOnClick,
                ),
              ], //row k backay
            ), //row
            Row(
              children: [
                //pehla button
                calc_button(
                  Number: '+',
                  bg: 0xFFf4d160,
                  tc: 0xFF000000,
                  callback: btnOnClick,
                ),
                calc_button(
                  Number: '-',
                  bg: 0xFFf4d160,
                  tc: 0xFF000000,
                  callback: btnOnClick,
                ),
                calc_button(
                  Number: '*',
                  bg: 0xFFf4d160,
                  tc: 0xFF000000,
                  callback: btnOnClick,
                ),
                calc_button(
                  Number: '/',
                  bg: 0xFFf4d160,
                  tc: 0xFF000000,
                  callback: btnOnClick,
                ),
              ], //row k backay
            ), //row
          ], // column k bachay
        ), //colum
      ), // body cont
    );
  }
}
